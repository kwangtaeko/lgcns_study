package com.example.myproject.repository;

import com.example.myproject.entity.About;
import org.springframework.data.repository.CrudRepository;

public interface AboutRepository extends CrudRepository<About, Long> {
}
